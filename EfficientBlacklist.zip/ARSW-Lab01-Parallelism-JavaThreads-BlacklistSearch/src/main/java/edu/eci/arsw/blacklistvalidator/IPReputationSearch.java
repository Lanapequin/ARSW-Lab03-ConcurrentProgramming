package edu.eci.arsw.blacklistvalidator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IPReputationSearch extends Thread {
    private int startIndex;
    private int endIndex;
    private String ipAddress;
    private HostBlacklistsDataSourceFacade facade;
    private List<Integer> occurrences;
    private AtomicInteger globalOccurrences;
    private HostBlackListsValidator validator;
    private int checkedCount = 0;

    public IPReputationSearch(int startIndex, int endIndex, String ipAddress, HostBlacklistsDataSourceFacade facade, AtomicInteger globalOccurrences, HostBlackListsValidator validator) {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.ipAddress = ipAddress;
        this.facade = facade;
        this.occurrences = new ArrayList<>();
        this.globalOccurrences = globalOccurrences;
        this.validator = validator;
    }

    @Override
    public void run() {
        for (int i = startIndex; i < endIndex && !validator.shouldStop(); i++) {
            checkedCount++;
            if (facade.isInBlackListServer(i, ipAddress)) {
                occurrences.add(i);
                int total = globalOccurrences.incrementAndGet();
                if (total >= HostBlackListsValidator.getBlackListAlarmCount()){
                    validator.stopSearch();
                    break;
                }
            }
        }
    }
}
